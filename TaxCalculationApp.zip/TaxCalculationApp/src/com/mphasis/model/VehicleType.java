package com.mphasis.model;

public enum VehicleType {
    PETROL,
    DIESEL,
    CNG_LPG
}
