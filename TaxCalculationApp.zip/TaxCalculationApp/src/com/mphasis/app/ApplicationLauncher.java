package com.mphasis.app;

import com.mphasis.service.AuthenticationService;
import com.mphasis.service.PropertyService;
import com.mphasis.service.VehicleService;
import com.mphasis.userinterface.ConsoleHelper;
import com.mphasis.userinterface.LoginScreen;
import com.mphasis.userinterface.MainMenuScreen;
import com.mphasis.userinterface.PropertyMenuScreen;
import com.mphasis.userinterface.TotalSummaryScreen;
import com.mphasis.userinterface.VehicleMenuScreen;
 
public class ApplicationLauncher {
 
    public static void main(String[] args) {
        new ApplicationLauncher().start();
    }
 
    private void start() {
        ConsoleHelper ui = new ConsoleHelper();
 
        // Services
        AuthenticationService authService = new AuthenticationService();
        PropertyService propertyService = new PropertyService();
        VehicleService vehicleService = new VehicleService();
 
        // UI screens
        LoginScreen loginScreen = new LoginScreen(ui, authService);
        PropertyMenuScreen propertyMenuScreen = new PropertyMenuScreen(ui, propertyService);
        VehicleMenuScreen vehicleMenuScreen = new VehicleMenuScreen(ui, vehicleService);
        TotalSummaryScreen totalSummaryScreen = new TotalSummaryScreen(ui, propertyService, vehicleService);
        MainMenuScreen mainMenuScreen = new MainMenuScreen(ui, propertyMenuScreen, vehicleMenuScreen, totalSummaryScreen);
 
        if (loginScreen.show()) {
            mainMenuScreen.show();
        }
    }
}