package com.mphasis.service.calculator;

import com.mphasis.model.BaseEntity;

public interface TaxCalculator<T extends BaseEntity> {
 
    double calculateTax(T entity);
}
