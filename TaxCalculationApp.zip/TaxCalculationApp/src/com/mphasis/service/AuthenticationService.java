package com.mphasis.service;

public class AuthenticationService {
	 
    private static final String DEFAULT_USERNAME = "anirudha";
    private static final String DEFAULT_PASSWORD = "anirudha@123";
 
    public boolean authenticate(String username, String password) {
        return DEFAULT_USERNAME.equals(username) && DEFAULT_PASSWORD.equals(password);
    }
}